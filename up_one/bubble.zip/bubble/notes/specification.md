The Bauble Specification is very light.

```json
{
  "name": "--",
  "version": "--",
  "dependencies": {

  },
  "devDependencies": {

  },
  "ignore": [
    "**/.*",
    "node_modules",
    "bower_components",
    "test",
    "tests"
  ]
}
```
